
import bcrypt from "bcrypt"

import mongoose, { Types } from "mongoose"
//import redisDb from "../database/redis.js"
import OTP from "../Models/Otp.Model.js"
import User from "../Models/User.Model.js"
import Session from "../Models/Session.Model.js"
import { loginSchema, registerSchema } from "../Validators/ZodSchema.js"
import z from "zod"
import { guestCookieName } from "../Middleware/guestDemo.Mw.js"
import { UptimeMonitor } from "../Models/UptimeMonitor.Model.js"
import { removeUptimeScheduler } from "../Services/uptimeScheduler.Service.js"



export const registerUser = async(req, res, next)=>{
    
    const {success , data , error} = registerSchema.safeParse(req.body) //sanitizing db inputs

    if(!success){
        return res.status(400).json({error: z.flattenError(error).fieldErrors})

    }
    const{email , name , password,otp} = data
    

    const otprecord= await OTP.findOne({email,otp})
       if(!otprecord){
        return res.status(400).json({error: " invalid otp "})
       }

       await otprecord.deleteOne() 
   
    const hashPassword = await bcrypt.hash(password, 12 ) 
  
    const userExist = await User.findOne({email})
    if(userExist){
        return res.status(409).json({
                error: "user already exist" ,
                message: "user already exist"
            })}

    
      const ssn = await mongoose.startSession();
    
        try {
     ssn.startTransaction()     

     const userId = new Types.ObjectId();

    
    const userDir = await User.create([{ //creating user collection here 
        _id:userId,
        name,
        email,
        password:hashPassword,
    }],{session: ssn })
        
 
      ssn.commitTransaction() 


    res.status(201).json({ message: "User Registered" });
        
      } catch (err){
        console.log(err)
        await ssn.abortTransaction(); 
      if(err.code === 121) {
      res
        .json({ error: "Invalid input, please enter valid details" });

      
    } else {
      next(err);
    }
        
      }      

}

export const loginUser = async(req, res, next)=>{
    try{
         const {success , data , error} = loginSchema.safeParse(req.body) //sanitizing db inputs

    if(!success){
        console.log(error)
        return res.status(400).json({error: z.flattenError(error).fieldErrors})
    }
    const{email, password} = data
    
    
    const user = await User.findOne({email}) 
    if(!user){
        return res.status(404).json({ error: "Invalid Credentials" });
    }

     if(user.deleted){ //soft delete check 
          return res.status(403).json({error: "your account is eleted contact admin"})
      }
      

    const ispassValid = await bcrypt.compare(password, user.password) 
    if(!ispassValid){
        return res.status(404).json({ error: "Invalid Credentials" });
    }
    
    


    const allSessions = await Session.find({userId :  user._id}) 
    if(allSessions.length >= 2){  
       await allSessions[0].deleteOne()  }
   
  
    const session = await Session.create({userId: user._id}) 
     const sessionExpiryTime = 60 * 1000 * 60 * 24 * 7;
     

    const isProduction = process.env.NODE_ENV === "production";
    res.cookie("sid", session._id.toString(), {
        httpOnly: true,
        signed: true,
        maxAge: sessionExpiryTime,
        sameSite: isProduction ? "none" : "lax",
        secure: isProduction,
    });

    // Clear guest cookie on login so the client is no longer in guest mode
    res.clearCookie(guestCookieName, {
        httpOnly: true,
        signed: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: process.env.NODE_ENV === "production" ? "none" : "lax",
    });

    // If an existing socket was connected under this guest session, migrate it to the user room
    const guestId = req.headers["x-guest-id"] || req.body?.guestId || req.signedCookies?.[guestCookieName];
    if (guestId) {
      const io = req.app.get("io");
      if (io) {
        const guestRoom = `guest:${guestId}`;
        const userRoom = `user:${user._id}`;
        try {
          const sockets = await io.in(guestRoom).fetchSockets(); // fetch all socket inside the guest room
          for (const s of sockets) {
            s.leave(guestRoom);  // migrating guest userroom
            s.join(userRoom);
            s.data.userId = user._id.toString();
            s.data.roomId = userRoom;
            s.data.roomIds = [userRoom];
            delete s.data.guestId;
            s.emit("roomMigrated", { roomId: userRoom });
          }
          if (sockets.length > 0) {
            console.log(`[Socket] Migrated ${sockets.length} socket(s) from ${guestRoom} to ${userRoom}`);
          }
        } catch (socketErr) {
          console.error("[Socket] Error migrating guest sockets on login:", socketErr);
        }
      }
    }

    res.json({
      message: "logged in",
      token: session._id.toString(),
      sessionId: session._id.toString(),
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        picture: user.picture,
        plan: user.plans || "free",
        role: user.role || "User",
      },
    });
}
    catch(err){
        console.log(err)
        next(err)
    }
}

    

export const userDetails = async(req, res)=>{ 
    console.log("req",req.user);
    const user = await User.findById(req.user._id)
    

    
    res.status(200).json({
        id: user._id,
        name: user.name, 
        email: user.email,
        picture: user.picture,
        plan: user.plans || "free",
        role: user.role || "User",
    })


}

export const getAllUsers = async (req, res) => {
    try {
        
        const page = Math.max(1, parseInt(req.query.page, 10) || 1);
        const limit = Math.max(1, Math.min(100, parseInt(req.query.limit, 10) || 10)); 
        const skip = (page - 1) * limit;

      
        const [users, totalUsers] = await Promise.all([
            User.find({ deleted: false })
                .select('_id name email role') 
                .skip(skip)
                .limit(limit)
                .lean() ,
            User.countDocuments({ deleted: false })
        ]);

       
        const totalPages = Math.ceil(totalUsers / limit);

    
        if (!users || users.length === 0) {
            return res.status(200).json({
                success: true,
                data: [],
                pagination: {
                    currentPage: page,
                    totalPages: 0,
                    totalUsers: 0,
                    limit,
                    hasNextPage: false,
                    hasPrevPage: false
                }
            });
        }

        return res.status(200).json({
            success: true,
            data: users,
            pagination: {
                currentPage: page,
                totalPages,
                totalUsers,
                limit,
                hasNextPage: page < totalPages,
                hasPrevPage: page > 1
            }
        });

    } catch (error) {
        console.error("Error fetching users:", error);
        return res.status(500).json({
            success: false,
            message: "Internal server error while fetching users.",
            error: process.env.NODE_ENV === "development" ? error.message : undefined
        });
    }
};

export const adminPowerlogout = async(req,res,next)=>{ //rbac
  try {
      const id = req.params.userId
    await Session.deleteMany({userId:id}) 
     res.status(204).end();
    
  } catch (error) {
    next(error)
    }}



export const DeleteUser = async (req, res, next) => { //rbac
  const { userId } = req.params;
  if (req.user._id.toString() === userId) {  //disabling self delete 
    return res.status(403).json({ error: "you cannot delete yourself" });
  }

  try {
    await Session.deleteMany({ userId });
    await User.findByIdAndUpdate(userId, { deleted: true }); //soft delete 

    // Disconnect user's active sockets if any
    const io = req.app.get("io");
    if (io) {
      try {
        io.in(`user:${userId}`).disconnectSockets(true);
      } catch (sockErr) {
        console.warn(`[DeleteUser] Could not disconnect sockets for user ${userId}:`, sockErr.message);
      }
    }

    // Pause and remove schedulers for user's active monitors
    try {
      const activeMonitors = await UptimeMonitor.find({ userId, status: "active" });
      for (const monitor of activeMonitors) {
        await removeUptimeScheduler(monitor._id, `user:${userId}`);
        await UptimeMonitor.findByIdAndUpdate(monitor._id, { status: "paused" });
      }
    } catch (schedErr) {
      console.warn(`[DeleteUser] Could not pause schedulers for user ${userId}:`, schedErr.message);
    }

    return res.status(200).json({
      success: true,
      message: "User deleted and active monitors paused successfully"
    });
  } catch (error) {
    next(error);
  }
};    


export const logout = async (req, res) => {
    const authHeader = req.headers.authorization;
    const bearerToken = authHeader && authHeader.startsWith("Bearer ") ? authHeader.slice(7).trim() : null;
    const sid = req.sessionId || req.signedCookies?.sid || bearerToken || req.headers["x-session-id"];
    const session = sid && mongoose.Types.ObjectId.isValid(sid) ? await Session.findByIdAndDelete(sid) : null;

    const io = req.app.get("io");
    if (session?.userId && io) {
      try {
        io.in(`user:${session.userId}`).disconnectSockets(true);
      } catch (err) {
        console.error("[Socket] Error disconnecting user sockets on logout:", err);
      }
    }

    const isProd = process.env.NODE_ENV === "production";
    res.clearCookie("sid", {
        httpOnly: true,
        signed: true,
        sameSite: isProd ? "none" : "lax",
        secure: isProd,
    });
    res.clearCookie(guestCookieName, {
        httpOnly: true,
        signed: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: process.env.NODE_ENV === "production" ? "none" : "lax",
    });
    res.status(204).end();
};




