import { DnsRecord } from "../Models/dnsRecord.Model.js";
import { dnsRecordCheck } from "../queue/dnsRecordCheck.Queue.js";
import { normalizeHostname, DnsServiceError } from "../Services/dnsRecordtype.Service.js";
import { releaseGuestDemoReservation } from "../Middleware/guestDemoUsage.Mw.js";

export const dnsRecordLookup = async (req, res) => {
  let record = null;
  try {
    const rawUrl = req.body?.url;

    if (!rawUrl || typeof rawUrl !== "string" || !rawUrl.trim()) {
      return res.status(400).json({
        success: false,
        error: "Missing or invalid 'url' in request body",
      });
    }

    let hostname = req.targetHostname;
    if (!hostname) {
      try {
        hostname = normalizeHostname(rawUrl);
      } catch (err) {
        const status = err instanceof DnsServiceError ? err.statusCode : 400;
        return res.status(status).json({ success: false, error: err.message });
      }
    }

    const userId = req.user?._id?.toString();
    const guestId = req.guestId;
    const roomId = userId ? `user:${userId}` : `guest:${guestId}`;

    // 1. Create DB record with status 'queued'
    record = await DnsRecord.create({
      ...(userId ? { userId } : { guestId }),
      roomId,
      url: hostname,
      status: "queued",
    });

    const dnsRecordId = record._id.toString();

    // 2. Add job to queue
    const job = await dnsRecordCheck.add(
      "check-dns-records",
      {
        targetUrl: hostname,
        userId,
        guestId,
        dnsRecordId,
        roomId,
      },
      {
        jobId: dnsRecordId,
      }
    );

    return res.status(202).json({
      success: true,
      message: "DNS record lookup started",
      jobId: job.id,
      dnsRecordId,
      roomId,
      guest: !userId,
      remaining: req.guestDemoRemaining,
      totalLimit: req.guestDemoTotalLimit,
      data: record,
    });
  } catch (err) {
    console.error("[dnsRecordLookup] error:", err);

    await releaseGuestDemoReservation(req);

    // Rollback created document if queue addition failed
    if (record?._id) {
      await DnsRecord.findByIdAndDelete(record._id).catch(() => {});
    }

    return res.status(500).json({
      success: false,
      message: "Failed to queue DNS lookup",
      error: err.message || "Internal server error",
    });
  }
};

export const getDnsRecordResults = async (req, res) => {
  try {
    const userId = req.user._id;
    const {
      page = 1,
      limit = 20,
      url,
      status = "completed",
    } = req.query;

    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const limitNum = Math.min(100, Math.max(1, parseInt(limit, 10) || 20));
    const skip = (pageNum - 1) * limitNum;

    const query = {
      userId,
      result: { $ne: null },
    };

    if (status) {
      query.status = status;
    }

    if (url) {
      query.url = { $regex: url.trim(), $options: "i" };
    }

    const [results, total] = await Promise.all([
      DnsRecord.find(query)
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limitNum)
        .lean(),
      DnsRecord.countDocuments(query),
    ]);

    return res.status(200).json({
      success: true,
      data: results,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages: Math.ceil(total / limitNum),
      },
    });
  } catch (error) {
    console.error("getDnsRecordResults error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch DNS record results",
    });
  }
};

export const getDnsRecordById = async (req, res) => {
  try {
    const userId = req.user?._id?.toString();
    const guestId = req.guestId;
    const { id } = req.params;

    const query = { _id: id };
    if (userId) {
      query.userId = userId;
    } else if (guestId) {
      query.guestId = guestId;
    } else {
      return res.status(401).json({
        success: false,
        message: "Authentication or guest session required",
      });
    }

    const result = await DnsRecord.findOne(query).lean();

    if (!result) {
      return res.status(404).json({
        success: false,
        message: "DNS record not found",
      });
    }

    return res.status(200).json({
      success: true,
      data: result,
    });
  } catch (error) {
    console.error("getDnsRecordById error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch DNS record",
    });
  }
};

export const getDnsRecordStatus = async (req, res) => {
  try {
    const userId = req.user?._id?.toString();
    const guestId = req.guestId;
    const { id } = req.params;

    const query = { _id: id };
    if (userId) {
      query.userId = userId;
    } else if (guestId) {
      query.guestId = guestId;
    } else {
      return res.status(401).json({
        success: false,
        message: "Authentication or guest session required",
      });
    }

    const result = await DnsRecord.findOne(query).lean();

    if (!result) {
      return res.status(404).json({
        success: false,
        message: "DNS record not found",
      });
    }

    return res.status(200).json({
      success: true,
      jobId: result._id.toString(),
      dnsRecordId: result._id.toString(),
      status: result.status,
      result: result.result,
      error: result.error || null,
      createdAt: result.createdAt,
      completedAt: result.completedAt || null,
    });
  } catch (error) {
    console.error("getDnsRecordStatus error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch DNS record status",
    });
  }
};
